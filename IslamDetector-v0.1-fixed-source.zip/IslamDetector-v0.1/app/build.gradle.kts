plugins { id("com.android.application") }

android {
    namespace = "com.islamdetector.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.islamdetector.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes { release { isMinifyEnabled = false } }
}
