package com.islamdetector.app;
public class TargetRecord { public long time; public String deviceResult; public String aiSuggestion; public String excavationTruth; public boolean protectedGold; public double lat,lon; public int confidence,zeroing,sensitivity; }
