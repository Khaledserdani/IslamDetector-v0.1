package com.islamdetector.app;
public class SweepPass { public long time; public float[] samples; public float heading; public String mode; }
