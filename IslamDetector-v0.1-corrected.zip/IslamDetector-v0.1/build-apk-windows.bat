@echo off
if not exist gradlew.bat (
 echo Gradle Wrapper not found. Open project in Android Studio and build/sync first, or install Gradle and run: gradle wrapper
 exit /b 1
)
call gradlew.bat clean assembleDebug
if errorlevel 1 exit /b %errorlevel%
copy /Y app\build\outputs\apk\debug\app-debug.apk IslamDetector-v0.1-debug.apk
