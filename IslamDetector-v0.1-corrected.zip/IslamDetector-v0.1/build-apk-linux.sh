#!/usr/bin/env sh
set -e
[ -x ./gradlew ] || { echo "Gradle Wrapper missing. Generate it with Gradle/Android Studio first."; exit 1; }
./gradlew clean assembleDebug
cp app/build/outputs/apk/debug/app-debug.apk IslamDetector-v0.1-debug.apk
